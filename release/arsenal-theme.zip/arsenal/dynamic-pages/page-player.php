<?php
/**
 * Template Name: Статистика игрока
 * 
 * Страница отображения полной статистики игрока ФК Арсенал Дзержинск
 */

// Получаем ID игрока из параметра URL (поддерживаем и rewrite rule, и GET параметр)
// player_id может быть как строкой (player_id из БД) так и числом (id из БД)
$player_id = get_query_var( 'player_id' );
if ( ! $player_id ) {
	$player_id = isset( $_GET['player_id'] ) ? sanitize_text_field( $_GET['player_id'] ) : '';
}

// Если ID не передан или игрок не найден, используем дефолтный title
$custom_title = '';
if ( $player_id ) {
	if ( function_exists( 'arsenal_get_player_data' ) ) {
		$player = arsenal_get_player_data( $player_id );
	} else {
		$player = null;
	}
	if ( $player ) {
		$display_name = $player->full_name ?: trim($player->last_name . ' ' . $player->first_name);
		$position_name = $player->position_name ?? 'игрок';
		$custom_title = $display_name . ' - игрок команды Арсенал, позиция - ' . $position_name;
		
		// Устанавливаем кастомный title
		add_filter( 'pre_get_document_title', function() use ( $custom_title ) {
			return $custom_title;
		}, 999 );
	}
}

get_header();

// Если ID не передан, показываем ошибку
if ( ! $player_id ) {
	?>
	<main class="player-page">
		<div class="player-hero">
			<div class="player-container">
				<div class="player-not-found">
					<h1>Игрок не указан</h1>
					<p>Не указан ID игрока. Пожалуйста, используйте корректную ссылку на страницу игрока.</p>
				</div>
			</div>
		</div>
	</main>
	<?php
	get_footer();
	return;
}

// Получаем данные игрока
// Функция: arsenal_get_player_data() - см. inc/player-functions.php
if ( function_exists( 'arsenal_get_player_data' ) ) {
	$player = arsenal_get_player_data( $player_id );
} else {
	$player = null;
}

if ( ! $player ) {
	?>
	<main class="player-page">
		<div class="player-hero">
			<div class="player-container">
				<div class="player-not-found">
					<h1>Игрок не найден</h1>
					<p>Игрок с ID <?php echo esc_html( $player_id ); ?> не найден в базе данных.</p>
				</div>
			</div>
		</div>
	</main>
	<?php
	get_footer();
	return;
}

// Сохраняем оригинальный ID для URL
$url_player_id = $player_id;

// ВАЖНО: Используем реальный player_id из БД для запросов к БД
$player_id = $player->player_id;

// Получаем position_code для определения позиции на поле
if ( function_exists( 'arsenal_get_player_position' ) ) {
	$position_code = arsenal_get_player_position( $player->position_id );
} else {
	$position_code = null;
}

// Название позиции берем прямо из БД
$position_name = $player->position_name ?? 'Не указана';

// Display name: используем full_name или собираем из first_name + last_name
$display_name = $player->full_name ?: trim($player->last_name . ' ' . $player->first_name);

// Вычисляем возраст
$age = null;
if ( $player->birth_date ) {
	$birth_date = new DateTime( $player->birth_date );
	$today = new DateTime();
	$age = $today->diff( $birth_date )->y;
	if ( $age && function_exists( 'arsenal_pluralize_years' ) ) {
		$age_display = arsenal_pluralize_years( $age );
	} else {
		$age_display = $age;
	}
}

// Гражданство
$citizenship = $player->citizenship ?? 'Беларусь';

// Команда (основа/резерв)
global $wpdb;
if ( function_exists( 'arsenal_get_player_squad_type' ) ) {
	$squad_type = arsenal_get_player_squad_type( $player_id );
} else {
	$squad_type = 'Основа';
}

// Определяем выбранный турнир (из GET или по умолчанию 71CFDAA6)
$selected_tournament_id = isset( $_GET['tournament'] ) ? sanitize_text_field( $_GET['tournament'] ) : '71CFDAA6';

// Получаем ВСЕ данные за один вызов (оптимизация: вместо 5 отдельных запросов)
if ( function_exists( 'arsenal_get_player_full_data' ) ) {
	$player_data = arsenal_get_player_full_data( $player_id, $selected_tournament_id );
} else {
	$player_data = array(
		'seasons' => array(),
		'stats' => null,
		'events' => array(),
		'years' => array(),
		'yearly_stats' => array(),
		'selected_year' => intval( date( 'Y' ) ),
	);
}

$available_seasons = $player_data['seasons'] ?? array();
$selected_season_stats = $player_data['stats'];
$player_events = $player_data['events'] ?? array();
$available_years = $player_data['years'] ?? array();
$years_stats = $player_data['yearly_stats'] ?? array(); // Гарантируем что это всегда массив
$selected_year = $player_data['selected_year'] ?? intval( date( 'Y' ) ); // Получаем год из данных

// Применяем коррекции статистики (если они есть в таблице wp_arsenal_player_stats_corrections)
// Передаем год чтобы применять коррекции только для конкретного года
if ( function_exists( 'arsenal_apply_player_corrections' ) ) {
	$selected_season_stats = arsenal_apply_player_corrections( $selected_season_stats, $player_id, $selected_tournament_id, $selected_year );
}
if ( function_exists( 'arsenal_apply_player_corrections_to_yearly_stats' ) ) {
	$years_stats = arsenal_apply_player_corrections_to_yearly_stats( $years_stats, $player_id, $selected_tournament_id );
}

// Определяем название выбранного турнира
$selected_tournament_name = '';
if ( ! empty( $available_seasons ) ) {
	foreach ( $available_seasons as $season ) {
		if ( $season->tournament_id == $selected_tournament_id ) {
			$selected_tournament_name = $season->tournament_name;
			break;
		}
	}
	
	// Если турнир не найден, берем первый из доступных
	if ( empty( $selected_tournament_name ) && ! empty( $available_seasons ) ) {
		$selected_tournament_id = $available_seasons[0]->tournament_id;
		$selected_tournament_name = $available_seasons[0]->tournament_name;
		// Переполучаем данные с правильным турниром
		if ( function_exists( 'arsenal_get_player_full_data' ) ) {
			$player_data = arsenal_get_player_full_data( $player_id, $selected_tournament_id );
			$selected_season_stats = $player_data['stats'];
			$player_events = $player_data['events'];
			$years_stats = $player_data['yearly_stats'];
			$selected_year = $player_data['selected_year'] ?? intval( date( 'Y' ) );
			// Применяем коррекции для новыого турнира
			if ( function_exists( 'arsenal_apply_player_corrections' ) ) {
				$selected_season_stats = arsenal_apply_player_corrections( $selected_season_stats, $player_id, $selected_tournament_id, $selected_year );
			}
			if ( function_exists( 'arsenal_apply_player_corrections_to_yearly_stats' ) ) {
				$years_stats = arsenal_apply_player_corrections_to_yearly_stats( $years_stats, $player_id, $selected_tournament_id );
			}
		}
	}
}

?>


<main class="player-page">
	<div class="player-hero">
		<div class="player-container">
			<!-- Профиль игрока -->
			<div class="player-profile-card">
				<!-- Фото -->
				<div class="player-photo-wrapper<?php echo empty( $player->photo_url ) ? ' player-photo-wrapper--placeholder' : ''; ?>">
					<?php if ( ! empty( $player->photo_url ) ) : ?>
							<?php
							$player_photo_url = trim( (string) $player->photo_url );
							$player_photo_src = function_exists( 'arsenal_convert_logo_url' )
								? arsenal_convert_logo_url( $player_photo_url )
								: esc_url( $player_photo_url );
							?>
							<img src="<?php echo esc_url( $player_photo_src ); ?>" alt="<?php echo esc_attr( $display_name ); ?>" loading="lazy">
					<?php else : ?>
					<?php 
					if ( function_exists( 'arsenal_render_camera_placeholder' ) ) {
						arsenal_render_camera_placeholder();
					}
					?>
					<?php endif; ?>
				</div>
				
				<!-- Информация игрока -->
				<div class="player-info-section">
					<!-- Заголовок с номером и именем -->
					<div class="player-header">
							<?php if ( ! empty( $player->shirt_number ) ) : ?>
						<?php endif; ?>
						
						<div class="player-name-block">
							<h1 class="player-name"><?php echo esc_html( $display_name ); ?></h1>
								<?php if ( ! empty( $position_name ) ) : ?>
								<span class="player-position-tag"><?php echo esc_html( $position_name ); ?></span>
							<?php endif; ?>
						</div>
					</div>
					
					<!-- Статистика характеристик -->
					<div class="player-stats-grid">
						<?php if ( $age !== null ) : ?>
							<div class="stat-box">
								<div class="stat-box-label">Возраст</div>
								<div class="stat-box-value"><?php echo esc_html( $age_display ?? $age ); ?></div>
							</div>
						<?php endif; ?>
						
						<?php if ( ! empty( $player->height_cm ) ) : ?>
							<div class="stat-box">
								<div class="stat-box-label">Рост</div>
								<div class="stat-box-value"><?php echo esc_html( $player->height_cm ); ?><span class="unit">см</span></div>
							</div>
						<?php endif; ?>
						
						<?php if ( ! empty( $player->weight_kg ) ) : ?>
							<div class="stat-box">
								<div class="stat-box-label">Вес</div>
								<div class="stat-box-value"><?php echo esc_html( $player->weight_kg ); ?><span class="unit">кг</span></div>
							</div>
						<?php endif; ?>
						
						<?php if ( ! empty( $player->dominant_foot ) ) : ?>
							<div class="stat-box">
								<div class="stat-box-label">Ведущая нога</div>
								<div class="stat-box-value"><?php echo esc_html( ucfirst( $player->dominant_foot ) ); ?></div>
							</div>
						<?php endif; ?>
						
						<div class="stat-box">
							<div class="stat-box-label">Команда</div>
							<div class="stat-box-value"><?php echo esc_html( $squad_type ); ?></div>
						</div>
						
						<div class="stat-box">
							<div class="stat-box-label">Гражданство</div>
							<div class="stat-box-value"><?php echo esc_html( $citizenship ); ?></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<!-- ПОЛОСА СТАТИСТИКИ ИГРОКА -->
	<section class="player-stats-bar" aria-label="<?php esc_attr_e( 'Статистика игрока', 'arsenal' ); ?>">
		<div class="player-stats-bar-container">
			<!-- Селектор турнира -->
			<?php if ( ! empty( $available_seasons ) && count( $available_seasons ) > 1 ) : ?>
		<div class="player-stats-bar-item player-stats-bar-item--tournament">
				<div class="custom-season-select">
					<span class="custom-season-select-trigger player-stats-bar-number">
						<?php echo esc_html( $selected_tournament_name ); ?>
					</span>
					<div class="custom-season-select-dropdown">
						<?php foreach ( $available_seasons as $season ) : ?>
							<a href="?page_id=<?php echo get_the_ID(); ?>&player_id=<?php echo esc_attr( $url_player_id ); ?>&tournament=<?php echo esc_attr( $season->tournament_id ); ?>" 
							   class="<?php echo ( $selected_tournament_id === $season->tournament_id ) ? 'selected' : ''; ?>">
								<?php echo esc_html( $season->tournament_name ); ?>
							</a>
						<?php endforeach; ?>
					</div>
				</div>
				<span class="player-stats-bar-label">Турнир</span>
			</div>
			<script>
			(function() {
				const select = document.querySelector('.custom-season-select');
				const trigger = select.querySelector('.custom-season-select-trigger');
				
				trigger.addEventListener('click', function(e) {
					e.stopPropagation();
					select.classList.toggle('active');
				});
				
				// Закрытие при клике вне селектора
				document.addEventListener('click', function(e) {
					if (!select.contains(e.target)) {
						select.classList.remove('active');
					}
				});
			})();
			</script>
			<?php else : ?>
		<div class="player-stats-bar-item">
				<span class="player-stats-bar-number"><?php echo esc_html( $selected_tournament_name ); ?></span>
				<span class="player-stats-bar-label">Турнир</span>
			</div>
			<?php endif; ?>
			
			
			<?php if ( $selected_season_stats ) : ?>
				<div class="player-stats-bar-item">
					<span class="player-stats-bar-number"><?php echo esc_html( number_format( $selected_season_stats->minutes_played, 0, '', ' ' ) ); ?></span>
					<span class="player-stats-bar-label">Минут за сезон</span>
				</div>
				<div class="player-stats-bar-item">
					<span class="player-stats-bar-number"><?php echo esc_html( $selected_season_stats->matches_played ); ?></span>
					<span class="player-stats-bar-label">Матчей сыграно</span>
				</div>
				<div class="player-stats-bar-item">
					<?php if ($position_code === 'A98B3A74') : ?>
						<span class="player-stats-bar-number"><?php echo esc_html( $selected_season_stats->goals_conceded ?? '0' ); ?></span>
						<span class="player-stats-bar-label">Голов пропущено</span>
					<?php else : ?>
						<span class="player-stats-bar-number"><?php echo esc_html( $selected_season_stats->goals ); ?></span>
						<span class="player-stats-bar-label">Голов забито</span>
					<?php endif; ?>
				</div>
				<div class="player-stats-bar-item">
					<span class="player-stats-bar-number"><?php echo esc_html( $selected_season_stats->assists ); ?></span>
					<span class="player-stats-bar-label">Ассистов</span>
				</div>
				<div class="player-stats-bar-item">
					<span class="player-stats-bar-number"><?php echo esc_html( $selected_season_stats->yellow_cards ); ?></span>
					<span class="player-stats-bar-label">Жёлтых карточек</span>
				</div>
				<div class="player-stats-bar-item">
					<span class="player-stats-bar-number"><?php echo esc_html( $selected_season_stats->red_cards ); ?></span>
					<span class="player-stats-bar-label">Красных карточек</span>
				</div>
			<?php else : ?>
				<div class="player-stats-bar-item">
					<span class="player-stats-bar-number">—</span>
					<span class="player-stats-bar-label">Минут за сезон</span>
				</div>
				<div class="player-stats-bar-item">
					<span class="player-stats-bar-number">—</span>
					<span class="player-stats-bar-label">Матчей сыграно</span>
				</div>
				<div class="player-stats-bar-item">
					<span class="player-stats-bar-number">—</span>
					<span class="player-stats-bar-label"><?php echo $position_code === 'A98B3A74' ? 'Голов пропущено' : 'Голов забито'; ?></span>
				</div>
				<div class="player-stats-bar-item">
					<span class="player-stats-bar-number">—</span>
					<span class="player-stats-bar-label">Ассистов</span>
				</div>
				<div class="player-stats-bar-item">
					<span class="player-stats-bar-number">—</span>
					<span class="player-stats-bar-label">Жёлтых карточек</span>
				</div>
				<div class="player-stats-bar-item">
					<span class="player-stats-bar-number">—</span>
					<span class="player-stats-bar-label">Красных карточек</span>
				</div>
			<?php endif; ?>
		</div>
	</section>
	
	<!-- СЕКЦИЯ СО СТАТИСТИКОЙ -->
	<div class="player-content">
		<div class="content-container">
			<!-- Сетка основных блоков: Позиция + Матчи + Биография -->
			<div class="player-sections-grid">
				<!-- Позиция на поле -->
			<div class="position-section" data-position-section>
					<h2 class="section-title">
						<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
						Позиция на поле
					</h2>
					<div class="field-container">
						<svg class="field-svg" width="320" height="214" viewBox="0 0 320 214" fill="none" xmlns="http://www.w3.org/2000/svg">
							<g clip-path="url(#clip0_81_97)">
								<path d="M0 10C0 4.47715 4.47715 0 10 0H310C315.523 0 320 4.47715 320 10V203.328C320 208.851 315.523 213.328 310 213.328H10C4.47715 213.328 0 208.851 0 203.328V10Z" fill="url(#paint0_linear_81_97)"/>
								<path opacity="0.8" d="M309.33 10.6664H10.6704V202.662H309.33V10.6664Z" stroke="white" stroke-width="1.06664"/>
								<path opacity="0.8" d="M160 10.6664V202.662" stroke="white" stroke-width="1.06664"/>
								<path opacity="0.8" d="M160 132.263C174.138 132.263 185.599 120.802 185.599 106.664C185.599 92.5259 174.138 81.0646 160 81.0646C145.862 81.0646 134.401 92.5259 134.401 106.664C134.401 120.802 145.862 132.263 160 132.263Z" stroke="white" stroke-width="1.06664"/>
								<path opacity="0.8" d="M160 108.371C160.943 108.371 161.707 107.607 161.707 106.664C161.707 105.721 160.943 104.957 160 104.957C159.057 104.957 158.293 105.721 158.293 106.664C158.293 107.607 159.057 108.371 160 108.371Z" fill="white"/>
								<path opacity="0.8" d="M309.33 42.6656H266.664V170.662H309.33V42.6656Z" stroke="white" stroke-width="1.06664"/>
								<path opacity="0.8" d="M309.33 74.6648H292.263V138.663H309.33V74.6648Z" stroke="white" stroke-width="1.06664"/>
								<path opacity="0.8" d="M283.73 107.731C284.319 107.731 284.797 107.253 284.797 106.664C284.797 106.075 284.319 105.597 283.73 105.597C283.141 105.597 282.664 106.075 282.664 106.664C282.664 107.253 283.141 107.731 283.73 107.731Z" fill="white"/>
								<path opacity="0.8" d="M315.729 89.5978H309.33V123.73H315.729V89.5978Z" stroke="white" stroke-width="1.06664"/>
								<path opacity="0.8" d="M53.336 42.6656H10.6704V170.662H53.336V42.6656Z" stroke="white" stroke-width="1.06664"/>
								<path opacity="0.8" d="M27.7366 74.6648H10.6704V138.663H27.7366V74.6648Z" stroke="white" stroke-width="1.06664"/>
								<path opacity="0.8" d="M36.2698 107.731C36.8589 107.731 37.3364 107.253 37.3364 106.664C37.3364 106.075 36.8589 105.597 36.2698 105.597C35.6807 105.597 35.2031 106.075 35.2031 106.664C35.2031 107.253 35.6807 107.731 36.2698 107.731Z" fill="white"/>
								<path opacity="0.8" d="M10.6704 89.5978H4.27055V123.73H10.6704V89.5978Z" stroke="white" stroke-width="1.06664"/>
								<path opacity="0.8" d="M10.6743 17.0701C14.9409 17.0649 17.0715 14.929 17.0663 10.6625" stroke="white" stroke-width="1.06664"/>
								<path opacity="0.8" d="M309.33 17.0663C305.063 17.0662 302.93 14.9329 302.93 10.6664" stroke="white" stroke-width="1.06664"/>
								<path opacity="0.8" d="M10.6817 196.25C14.9483 196.266 17.074 198.406 17.0589 202.673" stroke="white" stroke-width="1.06664"/>
								<path opacity="0.8" d="M309.375 196.308C305.109 196.247 302.945 198.349 302.884 202.616" stroke="white" stroke-width="1.06664"/>
							</g>
							<defs>
								<linearGradient id="paint0_linear_81_97" x1="0" y1="106.664" x2="320" y2="106.664" gradientUnits="userSpaceOnUse">
									<stop stop-color="#00A63E"/>
									<stop offset="1" stop-color="#008236"/>
								</linearGradient>
								<clipPath id="clip0_81_97">
									<path d="M0 10C0 4.47715 4.47715 0 10 0H310C315.523 0 320 4.47715 320 10V203.328C320 208.851 315.523 213.328 310 213.328H10C4.47715 213.328 0 208.851 0 203.328V10Z" fill="white"/>
								</clipPath>
							</defs>
						</svg>
						<?php
						// Определяем позицию на поле в процентах от размеров SVG (320x214)
						$field_positions = array();
						if ( function_exists( 'arsenal_get_field_positions' ) ) {
							$field_positions = arsenal_get_field_positions();
						}
						// Fallback: используем позицию полузащитника M (55%, 50%)
						$pos = ( isset($field_positions[$position_code]) ? $field_positions[$position_code] : ( isset($field_positions['M']) ? $field_positions['M'] : array('x' => 55, 'y' => 50) ) );
						?>
						<div class="player-position-marker" style="left: <?php echo esc_attr( $pos['x'] ); ?>%; top: <?php echo esc_attr( $pos['y'] ); ?>%; transform: translate(-50%, -50%);">
						<div class="marker-content">
							<div class="marker-number"><?php echo esc_html( $player->shirt_number ? $player->shirt_number : '?' ); ?></div>
						</div>
					</div>
				</div>
				<div class="player-position-label">
					<div class="position-label-container">
						<?php if ($player->shirt_number) : ?>
							<div class="position-label-shirt">
								<div class="shirt-badge"><?php echo esc_html( $player->shirt_number ); ?></div>
							</div>
						<?php endif; ?>
						<div class="position-label-info">
							<div class="player-name-label"><?php echo esc_html( $display_name ); ?></div>
							<?php if ( $position_name ) : ?>
								<div class="position-name-label"><?php echo esc_html( $position_name ); ?></div>
							<?php endif; ?>
						</div>
						<div class="position-label-icon">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
								<path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
								<path d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
							</svg>
						</div>
					</div>
				</div>
			</div>
			
			<!-- События игрока -->
			<div class="recent-matches-section" data-player-events-section>
				<h2 class="section-title">
					<svg><use xlink:href="<?php echo esc_attr( ARSENAL_THEME_URI ); ?>/assets/images/sprite.svg#icon-staff-stat"></use></svg>
					События турнира <?php echo esc_html( $selected_tournament_name ); ?>
				</h2>
				<?php if ( ! empty( $player_events ) ) : ?>
					<div class="matches-wrapper" data-matches-table>
						<table class="matches-table">
							<thead>
								<tr>
									<th>Дата</th>
									<th>Матч</th>
									<th>Счёт</th>
									<th>Минут</th>
									<th>Голы</th>
									<th>Ассисты</th>
									<th>ЖК</th>
									<th>КК</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $player_events as $match ) : ?>
									<tr>
										<td data-label="Дата"><?php echo esc_html( date( 'd.m.Y', strtotime( $match->match_date ) ) ); ?></td>
										<td data-label="Матч">
											<a href="<?php echo esc_url( home_url( '/match/' . $match->home_team_id . '/' . date( 'Y-m-d', strtotime( $match->match_date ) ) . '/' ) ); ?>" class="match-link">
												<?php echo esc_html( $match->home_team . ' - ' . $match->away_team ); ?>
											</a>
										</td>
										<td data-label="Счёт" class="match-score">
											<?php 
											if ( $match->home_score !== null && $match->away_score !== null ) {
												echo esc_html( $match->home_score . ':' . $match->away_score );
											} else {
												echo '—';
											}
											?>
										</td>
										<td data-label="Минут"><?php echo esc_html( $match->minutes_played ); ?></td>
										<td data-label="Голы"><?php echo $match->goals ? '⚽ ' . esc_html( $match->goals ) : '—'; ?></td>
										<td data-label="Ассисты"><?php echo $match->assists ? '👟 ' . esc_html( $match->assists ) : '—'; ?></td>
										<td data-label="ЖК"><?php echo $match->yellow_cards ? '🟨 ' . esc_html( $match->yellow_cards ) : '—'; ?></td>
										<td data-label="КК"><?php echo $match->red_cards ? '🟥 ' . esc_html( $match->red_cards ) : '—'; ?></td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
					<button class="toggle-matches-btn" data-toggle-matches>
						<span class="toggle-text">Показать все матчи</span>
						<svg class="toggle-icon" viewBox="0 0 24 24">
							<path fill="white" stroke="none" d="M7.33 24l9.3 0c1.26,0 2.25,-0.14 3.19,-0.49 0.99,-0.32 2.07,-1.05 2.71,-1.83 0.42,-0.56 0.73,-1.12 0.98,-1.79 0.31,-0.91 0.49,-1.93 0.49,-3.19l0 -9.4c0,-1.23 -0.18,-2.25 -0.49,-3.16 -0.46,-1.37 -1.26,-2.32 -2.42,-3.09 -1.2,-0.77 -2.91,-1.05 -4.49,-1.05l-9.16 0c-4.84,0 -7.44,2.49 -7.44,7.33l0 9.3c0,1.58 0.28,3.26 1.05,4.46 1.48,2.17 3.58,2.91 6.28,2.91l0 0z"/>
							<path fill="#FF1A1A" stroke="none" d="M12.11 13.16l4.21 -4.18c0.35,-0.38 1.01,-1.16 1.68,-1.16 1.09,0 1.96,1.23 0.63,2.43l-1.09 1.08c-0.94,0.95 -3.29,3.16 -3.89,3.86 -1.69,2 -2.25,0.99 -3.68,-0.45l-4.6 -4.6c-0.32,-0.32 -0.67,-0.56 -0.67,-1.19 0,-0.67 0.56,-1.27 1.3,-1.27 0.81,0 1.3,0.71 1.72,1.13 0.6,0.59 4.07,4.1 4.39,4.35l0 0z"/>
						</svg>
					</button>
				<?php else : ?>
					<p class="no-stats-message">📊 Нет данных о матчах игрока в этом турнире.</p>
				<?php endif; ?>
			</div>
			<!-- Биография -->
			<div class="biography-section">
				<h2 class="section-title">
					<svg><use xlink:href="<?php echo esc_attr( ARSENAL_THEME_URI ); ?>/assets/images/sprite.svg#icon-bio"></use></svg>
					Биография
				</h2>
				<div class="biography-text">
					<?php 
					if ( isset($player->biography) && $player->biography ) {
						echo wp_kses_post( $player->biography );
					}
					?>
				</div>
			</div>

			<!-- Статистика по годам для выбранного турнира -->
			<?php if ( ! empty( $years_stats ) ) : ?>
				<div class="seasons-table-section">
					<h2 class="section-title">
						<svg><use xlink:href="<?php echo esc_attr( ARSENAL_THEME_URI ); ?>/assets/images/sprite.svg#icon-staff-stat"></use></svg>
						Статистика по годам в <?php echo esc_html( $selected_tournament_name ); ?>
					</h2>
					<table class="stats-table">
						<thead>
							<tr>
								<th>Год</th>
								<th>Клуб</th>
								<th>Матчей сыграно</th>
								<th>Минут за сезон</th>								
								<th><?php echo $position_code === 'A98B3A74' ? 'Голов пропущено' : 'Голов забито'; ?></th>
								<th>Ассистов</th>
								<th>Жёлтых карточек</th>
								<th>Красных карточек</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $years_stats as $stat ) : ?>
								<tr>
									<td data-label="Год" class="year-cell"><?php echo esc_html( $stat->year ); ?></td>
									<td data-label="Команда">
										<?php 
										if ( function_exists( 'arsenal_get_player_team_by_year' ) ) {
											echo esc_html( arsenal_get_player_team_by_year( $player_id, $selected_tournament_id, $stat->year ) );
										} else {
											echo '—';
										}
										?>
									</td>
									<td data-label="Матчей сыграно"><?php echo esc_html( $stat->matches_played ); ?></td>
									<td data-label="Минут за сезон"><?php echo esc_html( number_format( $stat->minutes_played, 0, '', ' ' ) ); ?></td>
									<td data-label="<?php echo $position_code === 'A98B3A74' ? 'Голов пропущено' : 'Голов забито'; ?>">
										<?php 
											if ( $position_code === 'A98B3A74' ) {
												echo esc_html( $stat->goals_conceded ?? '0' );
											} else {
												echo esc_html( $stat->goals );
											}
										?>
									</td>
									<td data-label="Ассистов"><?php echo esc_html( $stat->assists ); ?></td>
									<td data-label="Жёлтых карточек"><?php echo esc_html( $stat->yellow_cards ); ?></td>
									<td data-label="Красных карточек"><?php echo esc_html( $stat->red_cards ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
			</div>
		</div>
	</div>
</main>

<script>
(function() {
	const section = document.querySelector('[data-player-events-section]');
	const wrapper = section ? section.querySelector('[data-matches-table]') : null;
	const btn = section ? section.querySelector('[data-toggle-matches]') : null;
	const positionSection = document.querySelector('[data-position-section]');
	
	if (!wrapper || !btn || !positionSection) return;
	
	// Синхронизация высот
	function syncHeights() {
		const positionHeight = positionSection.offsetHeight;
		section.style.minHeight = positionHeight + 'px';
	}
	
	// Функция для проверки, нужен ли коллапс
	function checkIfCollapseNeeded() {
		const wrapperHeight = wrapper.scrollHeight;
		
		// Если таблица длиннее 500px, применяем коллапс
		if (wrapperHeight > 500) {
			wrapper.classList.add('collapsed');
			btn.style.display = 'flex';
		}
	}
	
	// Проверяем после загрузки DOM
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function() {
			checkIfCollapseNeeded();
			syncHeights();
		});
	} else {
		checkIfCollapseNeeded();
		syncHeights();
	}
	
	// Переключение состояния
	btn.addEventListener('click', function(e) {
		e.preventDefault();
		wrapper.classList.toggle('collapsed');
		btn.classList.toggle('expanded');
		
		if (wrapper.classList.contains('collapsed')) {
			btn.querySelector('.toggle-text').textContent = 'Показать все матчи';
		} else {
			btn.querySelector('.toggle-text').textContent = 'Свернуть матчи';
		}
	});
	
	// Переопределяем при изменении размера окна
	let resizeTimeout;
	window.addEventListener('resize', function() {
		clearTimeout(resizeTimeout);
		resizeTimeout = setTimeout(function() {
			checkIfCollapseNeeded();
			syncHeights();
		}, 250);
	});
})();
</script>

<?php
get_footer();