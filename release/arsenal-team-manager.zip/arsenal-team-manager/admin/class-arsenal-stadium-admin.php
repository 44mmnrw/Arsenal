<?php
/**
 * Класс: Админ интерфейс для управления стадионами
 *
 * @package Arsenal
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arsenal_Stadium_Admin {
    
    /**
     * Инициализация
     */
    public function __init__() {
        add_action( 'admin_post_arsenal_create_stadium', array( $this, 'handle_create_stadium' ) );
        add_action( 'admin_post_arsenal_update_stadium', array( $this, 'handle_update_stadium' ) );
        add_action( 'admin_post_arsenal_delete_stadium', array( $this, 'handle_delete_stadium' ) );
    }
    
    /**
     * Отображение списка стадионов
     */
    public function render_stadiums_list() {
        // Проверка прав доступа
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'У вас нет прав для доступа к этому разделу.' );
        }
        
        // Получение параметров пагинации
        $paged = isset( $_GET['paged'] ) ? intval( $_GET['paged'] ) : 1;
        $per_page = 20;
        
        // Получение данных
        $result = Arsenal_Stadium_Manager::get_stadiums( $paged, $per_page );
        $stadiums = $result['stadiums'];
        $total_pages = $result['total_pages'];
        $total = $result['total'];
        
        // Включение шаблона
        include ARSENAL_TM_PLUGIN_DIR . 'admin/views/stadiums-list.php';
    }
    
    /**
     * Отображение формы добавления/редактирования стадиона
     */
    public function render_stadium_form() {
        // Проверка прав доступа
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'У вас нет прав для доступа к этому разделу.' );
        }
        
        $stadium = null;
        $is_edit = false;
        
        // Если редактируем стадион
        if ( isset( $_GET['stadium_id'] ) ) {
            $stadium_id = intval( $_GET['stadium_id'] );
            $stadium = Arsenal_Stadium_Manager::get_stadium( $stadium_id );
            
            if ( ! $stadium ) {
                wp_die( 'Стадион не найден.' );
            }
            
            $is_edit = true;
        }
        
        // Включение шаблона
        include ARSENAL_TM_PLUGIN_DIR . 'admin/views/stadium-form.php';
    }
    
    /**
     * Обработка создания стадиона
     */
    public function handle_create_stadium() {
        // Проверка прав
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Доступ запрещен.' );
        }
        
        // Проверка nonce
        if ( ! isset( $_POST['arsenal_stadium_nonce'] ) || 
             ! wp_verify_nonce( $_POST['arsenal_stadium_nonce'], 'arsenal_stadium_form' ) ) {
            wp_die( 'Проверка безопасности не пройдена.' );
        }
        
        // Подготовка данных
        $data = array(
            'name' => sanitize_text_field( $_POST['name'] ?? '' ),
            'city' => sanitize_text_field( $_POST['city'] ?? '' ),
            'capacity' => sanitize_text_field( $_POST['capacity'] ?? '' ),
            'open_date' => sanitize_text_field( $_POST['open_date'] ?? '' ),
            'photo_url' => esc_url_raw( $_POST['photo_url'] ?? '' ),
            'description' => wp_kses_post( $_POST['description'] ?? '' ),
            'history' => sanitize_text_field( $_POST['history'] ?? '' ),
            'contacts' => sanitize_text_field( $_POST['contacts'] ?? '' ),
            'infrastructure' => sanitize_text_field( $_POST['infrastructure'] ?? '' ),
            'tech_features' => sanitize_text_field( $_POST['tech_features'] ?? '' ),
            'sectors' => sanitize_text_field( $_POST['sectors'] ?? '' ),
            'stat_cards' => sanitize_text_field( $_POST['stat_cards'] ?? '' ),
            'to_get' => sanitize_text_field( $_POST['to_get'] ?? '' ),
            'on_date' => sanitize_text_field( $_POST['on_date'] ?? '' ),
        );
        
        // Fallback: обработка загрузки файла, если отправлен старый file input.
        if ( ! empty( $_FILES['photo'] ) && ! empty( $_FILES['photo']['name'] ) ) {
            $photo_url = $this->handle_image_upload();
            if ( $photo_url ) {
                $data['photo_url'] = $photo_url;
            }
        }
        
        // Создание стадиона
        $stadium_id = Arsenal_Stadium_Manager::create_stadium( $data );
        
        if ( $stadium_id ) {
            wp_redirect( admin_url( 'admin.php?page=arsenal-stadiums&success=1' ) );
        } else {
            wp_redirect( admin_url( 'admin.php?page=arsenal-stadium-add&error=1' ) );
        }
        
        exit;
    }
    
    /**
     * Обработка обновления стадиона
     */
    public function handle_update_stadium() {
        // Проверка прав
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Доступ запрещен.' );
        }
        
        // Проверка nonce
        if ( ! isset( $_POST['arsenal_stadium_nonce'] ) || 
             ! wp_verify_nonce( $_POST['arsenal_stadium_nonce'], 'arsenal_stadium_form' ) ) {
            wp_die( 'Проверка безопасности не пройдена.' );
        }
        
        $stadium_id = intval( $_POST['stadium_id'] ?? 0 );
        if ( ! $stadium_id ) {
            wp_die( 'ID стадиона не указан.' );
        }
        
        // Подготовка данных
        $data = array(
            'name' => sanitize_text_field( $_POST['name'] ?? '' ),
            'city' => sanitize_text_field( $_POST['city'] ?? '' ),
            'capacity' => sanitize_text_field( $_POST['capacity'] ?? '' ),
            'open_date' => sanitize_text_field( $_POST['open_date'] ?? '' ),
            'photo_url' => esc_url_raw( $_POST['photo_url'] ?? '' ),
            'description' => wp_kses_post( $_POST['description'] ?? '' ),
            'history' => sanitize_text_field( $_POST['history'] ?? '' ),
            'contacts' => sanitize_text_field( $_POST['contacts'] ?? '' ),
            'infrastructure' => sanitize_text_field( $_POST['infrastructure'] ?? '' ),
            'tech_features' => sanitize_text_field( $_POST['tech_features'] ?? '' ),
            'sectors' => sanitize_text_field( $_POST['sectors'] ?? '' ),
            'stat_cards' => sanitize_text_field( $_POST['stat_cards'] ?? '' ),
            'to_get' => sanitize_text_field( $_POST['to_get'] ?? '' ),
            'on_date' => sanitize_text_field( $_POST['on_date'] ?? '' ),
        );
        
        // Fallback: обработка загрузки файла, если отправлен старый file input.
        if ( ! empty( $_FILES['photo'] ) && ! empty( $_FILES['photo']['name'] ) ) {
            $photo_url = $this->handle_image_upload();
            if ( $photo_url ) {
                $data['photo_url'] = $photo_url;
            }
        }
        
        // Обновление стадиона
        $result = Arsenal_Stadium_Manager::update_stadium( $stadium_id, $data );
        
        if ( $result ) {
            wp_redirect( admin_url( 'admin.php?page=arsenal-stadiums&success=1' ) );
        } else {
            wp_redirect( admin_url( 'admin.php?page=arsenal-stadium-edit&stadium_id=' . $stadium_id . '&error=1' ) );
        }
        
        exit;
    }
    
    /**
     * Обработка удаления стадиона
     */
    public function handle_delete_stadium() {
        // Проверка прав
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Доступ запрещен.' );
        }
        
        // Проверка nonce
        if ( ! isset( $_GET['_wpnonce'] ) || 
             ! wp_verify_nonce( $_GET['_wpnonce'], 'arsenal_delete_stadium' ) ) {
            wp_die( 'Проверка безопасности не пройдена.' );
        }
        
        $stadium_id = intval( $_GET['stadium_id'] ?? 0 );
        if ( ! $stadium_id ) {
            wp_die( 'ID стадиона не указан.' );
        }
        
        $result = Arsenal_Stadium_Manager::delete_stadium( $stadium_id );
        
        if ( $result ) {
            wp_redirect( admin_url( 'admin.php?page=arsenal-stadiums&deleted=1' ) );
        } else {
            wp_redirect( admin_url( 'admin.php?page=arsenal-stadiums&error=1' ) );
        }
        
        exit;
    }
    
    /**
     * Обработка загрузки изображения
     *
     * @return string|false Относительный путь изображения или false при ошибке
     */
    private function handle_image_upload() {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        $attachment_id = media_handle_upload( 'photo', 0 );

        if ( is_wp_error( $attachment_id ) ) {
            error_log( 'Arsenal: Ошибка загрузки изображения - ' . $attachment_id->get_error_message() );
            return false;
        }

        $url = wp_get_attachment_url( $attachment_id );
        return $url ? esc_url_raw( $url ) : false;
    }
}
