<?php
/**
 * Template Name: Команда / Состав
 * Template Post Type: page
 *
 * Страница с составом команды - сетка карточек игроков
 *
 * @package Arsenal
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

global $wpdb;

// Получаем ID выбранного состава из метаполя
$squad_id = get_post_meta( get_the_ID(), '_arsenal_squad_id', true );

// Если не выбран состав в метаоксе, используем значение по умолчанию (Основной состав)
if ( empty( $squad_id ) ) {
	$squad_id = '21F3D7B3'; // По умолчанию: Основной состав
}

// Запрос: все игроки выбранного состава с активными контрактами
$sql = "SELECT p.*, pos.name as position_name, pos.id as position_id_numeric
	FROM {$wpdb->prefix}arsenal_players p
	LEFT JOIN {$wpdb->prefix}arsenal_positions pos ON p.position_id = pos.position_id
	INNER JOIN {$wpdb->prefix}arsenal_team_contracts tc ON p.player_id = tc.player_id
	WHERE tc.squad_id = %s
	AND (tc.contract_end IS NULL OR tc.contract_end >= CURDATE())
	ORDER BY pos.id ASC, p.shirt_number ASC";

$players = $wpdb->get_results( $wpdb->prepare( $sql, $squad_id ) );

// Получаем название состава из БД
$squad_name = 'Основной состав'; // По умолчанию
if ( ! empty( $squad_id ) ) {
	$squad_data = $wpdb->get_row(
		$wpdb->prepare(
			"SELECT squad_name FROM {$wpdb->prefix}arsenal_squad WHERE squad_id = %s",
			$squad_id
		)
	);
	if ( $squad_data && ! empty( $squad_data->squad_name ) ) {
		$squad_name = $squad_data->squad_name;
	}
}

// Группируем игроков по позициям
$players_by_position = array();
foreach ( $players as $player ) {
	$position = ! empty( $player->position_name ) ? $player->position_name : 'Неизвестная позиция';
	if ( ! isset( $players_by_position[ $position ] ) ) {
		$players_by_position[ $position ] = array();
	}
	$players_by_position[ $position ][] = $player;
}

?>

<main id="primary" class="site-main">
	<section class="teams-section">
		<div class="container">
			<div class="teams-header">
				<h1 class="teams-title"><?php echo esc_html( $squad_name ); ?></h1>
			</div>

			<?php if ( ! empty( $players ) ) : ?>
				<div class="teams-content">
					<?php
					foreach ( $players_by_position as $position_name => $position_players ) :
						// Применяем множественное число если в позиции больше 1 игрока
						$use_plural_for_position = count( $position_players ) > 1;
						$position_display = $use_plural_for_position && function_exists( 'arsenal_pluralize_position' ) 
							? arsenal_pluralize_position( $position_name ) 
							: $position_name;
					?>
						<div class="position-group">
							<h2 class="position-heading"><?php echo esc_html( $position_display ); ?></h2>
							
							<div class="players-grid">
								<?php foreach ( $position_players as $player ) : 
									// Получаем данные игрока
									// Проверка фото: валидная ссылка и не пуста
									$photo_url = '';
									if ( ! empty( $player->photo_url ) && is_string( $player->photo_url ) && strlen( trim( $player->photo_url ) ) > 0 ) {
										$photo_url = trim( $player->photo_url );
									}
									
									$position = ! empty( $player->position_name ) ? $player->position_name : 'Не указана';
									$shirt_number = ! empty( $player->shirt_number ) ? intval( $player->shirt_number ) : null;
									$name_display = ! empty( $player->full_name ) ? $player->full_name : 'Неизвестно';
									
									// Вычисляем возраст
									$age = '';
									if ( ! empty( $player->birth_date ) ) {
										try {
											$birth_date = new DateTime( $player->birth_date );
											$today = new DateTime();
											$age = $today->diff( $birth_date )->y;
										} catch ( Exception $e ) {
											$age = '';
										}
									}
									
									// Получаем статистику игрока текущего сезона
									$current_year = intval( get_option( 'arsenal_active_season_year', intval( date( 'Y' ) ) ) );
									
									// Получаем первый доступный турнир текущего года
									$first_tournament = $wpdb->get_var( $wpdb->prepare(
										"SELECT tournament_id FROM {$wpdb->prefix}arsenal_matches 
										 WHERE YEAR(match_date) = %d
										 LIMIT 1",
										$current_year
									) );
									
									if ( ! $first_tournament ) {
										$first_tournament = '71CFDAA6'; // По умолчанию
									}
									
									// Используем функцию arsenal_get_player_stats из inc/player-functions.php
									if ( function_exists( 'arsenal_get_player_stats' ) && ! empty( $player->player_id ) ) {
										$player_stats = arsenal_get_player_stats( $player->player_id, $first_tournament, $current_year );
										
										// Применяем корректировки статистики (как на странице игрока)
										if ( $player_stats && function_exists( 'arsenal_apply_player_corrections' ) ) {
											$player_stats = arsenal_apply_player_corrections( $player_stats, $player->player_id, $first_tournament, $current_year );
										}
										
										$matches_count = ( $player_stats && ! empty( $player_stats->matches_played ) ) ? intval( $player_stats->matches_played ) : 0;
										$goals_count = ( $player_stats && ! empty( $player_stats->goals ) ) ? intval( $player_stats->goals ) : 0;
										$assists_count = ( $player_stats && ! empty( $player_stats->assists ) ) ? intval( $player_stats->assists ) : 0;
									} else {
										// Fallback если функция не определена или player_id пустой
										$matches_count = 0;
										$goals_count = 0;
										$assists_count = 0;
									}
									
									// Параметры для ссылки
									$player_url = function_exists( 'arsenal_get_player_url' ) && ! empty( $player->id ) ? arsenal_get_player_url( $player->id ) : '#';
								?>
									<a href="<?php echo esc_url( $player_url ); ?>" class="player-card" title="<?php echo esc_attr( $name_display ); ?>">
										<!-- Левая колонка 50%: Фото + Номер -->
										<div class="player-card__photo">
											<?php if ( ! empty( $photo_url ) ) : ?>
												<img 
													src="<?php echo esc_url( $photo_url ); ?>" 
													alt="<?php echo esc_attr( $name_display ); ?>"
													class="player-card__image"
													loading="lazy"
												>
											<?php else : ?>
												<lottie-player src="<?php echo esc_url( get_template_directory_uri() . '/assets/animations/wired-outline-61-camera-hover-flash.json' ); ?>" background="transparent" style="width: 100%; height: 100%; min-height: 300px;"></lottie-player>
											<?php endif; ?>
											<?php if ( $shirt_number ) : ?>
												<div class="player-card__number">
													<?php echo esc_html( $shirt_number ); ?>
												</div>
											<?php endif; ?>
										</div>

										<!-- Правая колонка 50%: Информация -->
										<div class="player-card__info">
											<h3 class="player-card__name"><?php echo esc_html( $name_display ); ?></h3>
											<p class="player-card__position"><?php echo esc_html( $position ); ?></p>
											<?php if ( $age ) : ?>
											<p class="player-card__meta"><?php echo esc_html( function_exists( 'arsenal_pluralize_years' ) ? arsenal_pluralize_years( $age ) : $age . ' лет' ); ?> • Беларусь</p>
											<?php endif; ?>
										</div>

										<!-- Нижняя строка 100%: Статистика -->
										<div class="player-card__stats">
											<div class="player-stat">
												<span class="player-stat__label">Матчи</span>
												<span class="player-stat__value"><?php echo esc_html( $matches_count ); ?></span>
											</div>
											<div class="player-stat">
												<span class="player-stat__label">Голы</span>
												<span class="player-stat__value"><?php echo esc_html( $goals_count ); ?></span>
											</div>
											<div class="player-stat">
												<span class="player-stat__label">Пасы</span>
												<span class="player-stat__value"><?php echo esc_html( $assists_count ); ?></span>
											</div>
										</div>
									</a>
								<?php endforeach; ?>
							</div>
						</div>
					<?php
					endforeach;
					?>
				</div>
			<?php else : ?>
				<p class="no-players-message">Игроки основного состава не найдены</p>
			<?php endif; ?>
		</div>
	</section>
</main>

<?php
get_footer();

